package com.app.veraxe.utils;

/**
 * Created by hemanta on 12-11-2016.
 */
public class Constant {

    public static final String MyPREFERENCES = "MyPrefs";
    public static final String REGID = "regidKey";
    public static final String DEVICEID = "deviceidKey";
    public static final String DEVICETYPE= "android";
    public static final String AUTHKEY= "23de92fe7f8f6babd6fa31beacd81798";
    public static final String MIXPELTOKEN= "54c668981ba902203269c9c3a1a70fe2";
}
