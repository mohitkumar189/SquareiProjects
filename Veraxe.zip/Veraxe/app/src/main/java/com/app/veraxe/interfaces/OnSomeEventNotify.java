package com.app.veraxe.interfaces;

/**
 * Created by admin on 05-01-2016.
 */
     public interface OnSomeEventNotify {

         public void onListDataChange(int position, String text);


     }