package com.app.veraxe.interfaces;

/**
 * Created by admin on 02-12-2015.
 */
public interface OnCustomItemClicListener {
    public void onItemClickListener(int position, int flag);

}
