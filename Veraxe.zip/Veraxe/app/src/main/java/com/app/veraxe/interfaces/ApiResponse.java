package com.app.veraxe.interfaces;

import org.json.JSONObject;

/**
 * Created by seocor1 on 11/7/2016.
 */
public interface ApiResponse {

    public void getResponse(int method, JSONObject response);

}
