package com.app.justclap.utils;

/**
 * Created by hemanta on 15-04-2017.
 */

public class MyConstant {

    public static final String DEVICETYPE = "1";
    public static final String ISSUBSCRIBED = "IsSubscribed";
    public static final String ISPREMIUM = "IsPremium";
    public static final String ISREGISTERED = "IsRegistered";
    public static final String DEVICEID = "DeviceId";
    public static final String LOGGEDAS = "LoggedAs";
    public static final String GENDER = "Gender";
}
